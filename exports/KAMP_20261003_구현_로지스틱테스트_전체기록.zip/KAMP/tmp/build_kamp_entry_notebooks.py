from pathlib import Path
import os
import json
import nbformat
from nbclient import NotebookClient

ROOT=Path(__file__).resolve().parents[1]
runtime=ROOT/'tmp/notebook_runtime_20261003'
for name in ['ipython','jupyter','matplotlib']:(runtime/name).mkdir(parents=True,exist_ok=True)
os.environ['IPYTHONDIR']=str(runtime/'ipython')
os.environ['JUPYTER_RUNTIME_DIR']=str(runtime/'jupyter')
os.environ['MPLCONFIGDIR']=str(runtime/'matplotlib')

def save_execute(path,cells):
    n=nbformat.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'}})
    nbformat.write(n,path)
    NotebookClient(n,timeout=120,kernel_name='python3',resources={'metadata':{'path':str(ROOT)}}).execute()
    assert all(not any(o.get('output_type')=='error' for o in c.get('outputs',[])) for c in n.cells)
    nbformat.write(n,path);print('Executed:',path)

script=ROOT/'03.modeling/models/logistic_regression.py'
source=script.read_text(encoding='utf-8').split("if __name__=='__main__':")[0]
latest={d:sorted((ROOT/'output/logistic'/d).iterdir())[-1].relative_to(ROOT).as_posix() for d in ['cn7','rg3']}
cells=[nbformat.v4.new_markdown_cell('''# CN7 · RG3 로지스틱 회귀 학습·테스트
실제 실행 결과를 기본으로 표시합니다. 재학습은 `RUN_NEW_SEARCH=True`로 명시적으로 선택합니다.
고정 분할, 8개 입력 구성 × 15개 C × 2개 가중치, 4-fold OOF, 1001개 임계값입니다.
선택 OOF는 튜닝 점수이고 Test는 이미 관찰한 후속 평가입니다. 운영 승격은 하지 않습니다.
아래 셀은 logistic_regression.py의 코드 사본이며 공통 pipeline_runtime.py와 기존 OCSVM 변환을 재사용합니다.'''),
nbformat.v4.new_code_cell("from pathlib import Path\nROOT=next(p for p in [Path.cwd(),*Path.cwd().parents] if (p/'03.modeling').is_dir())\n__file__=str(ROOT/'03.modeling/models/logistic_regression.py')\nfrom IPython.display import display\n"),
nbformat.v4.new_code_cell(source),
nbformat.v4.new_code_cell('RUN_NEW_SEARCH=False\nDATASET="rg3"\nSAVED_RUNS='+repr(latest)+'\nif RUN_NEW_SEARCH:\n    SAVED_RUNS[DATASET]=str(run(DATASET).relative_to(ROOT))\n'),
nbformat.v4.new_code_cell('''rows=[]
for ds,relative in SAVED_RUNS.items():
    folder=ROOT/relative
    selection=read(folder/'selection_manifest.json')['choice']
    test=read(folder/'test_metrics.json')
    rows.append(dict(dataset=ds,scenario=selection['scenario'],C=selection['C'],class_weight=selection['class_weight'],threshold=selection['threshold'],OOF_F1=selection['F1'],test_F1=test['F1'],TP=test['TP'],FP=test['FP'],FN=test['FN']))
display(pd.DataFrame(rows))'''),
nbformat.v4.new_markdown_cell('## 계수와 RG3 분포 구간 안내\n계수는 인과 효과가 아닙니다. 구간별 수치는 고유 패턴의 위험 이력이며 제품 불량 확률이 아닙니다. 표본 부족은 반드시 구분합니다.'),
nbformat.v4.new_code_cell('''folder=ROOT/SAVED_RUNS[DATASET]
display(pd.read_csv(folder/'coefficients.csv').assign(abs_coefficient=lambda d:d.coefficient.abs()).sort_values('abs_coefficient',ascending=False).head(12))
g=read(folder/'distribution_guidance.json')
display(pd.DataFrame(g['ranges'])[['variable','interval','reference_patterns','reference_risks','reference_wilson95','evaluation_patterns','evaluation_risks','status','evaluation_support']].sort_values('reference_risks',ascending=False).head(20))
print((folder/'summary.txt').read_text(encoding='utf-8'))''')]
save_execute(ROOT/'03.modeling/models/05_logistic_regression.ipynb',cells)

cells=[nbformat.v4.new_markdown_cell('''# 7단계 로컬 운영 진입점
배치 → 저장 모델 추론 → 분포 변화 감지 → 원인 확인 후 후보 생성 → 분리 평가 → 교체/롤백.
기본 실행은 상태 조회만 합니다. 독립 평가 자료와 현장 기준이 없는 자동 운영은 시작하지 않습니다.
CLI의 각 명령과 같은 공통 구현을 사용합니다. 자세한 예시는 common/OPERATIONS_GUIDE.txt를 참고하세요.'''),
nbformat.v4.new_code_cell('''from pathlib import Path
import sys
ROOT=next(p for p in [Path.cwd(),*Path.cwd().parents] if (p/'03.modeling').is_dir())
sys.path.insert(0,str(ROOT/'03.modeling/common'))
from pipeline_runtime import Operations
DATASET='rg3'
ops=Operations(DATASET)
ops.registry()'''),
nbformat.v4.new_markdown_cell('''## 명시적으로 수행할 작업
1. 초기 후보의 버전과 지정 사유를 확인한 후 `ops.initialize(version, reason)`.
2. `ops.ingest(frame, label_source="실제 출처", coordinates_confirmed=True)`.
3. 표본이 누적되면 드리프트가 계산됩니다. 생산 시간 미확인 자료로 시간 성능을 주장하지 않습니다.
4. 원인 확인 후 `ops.retrain(kind, batch_ids, drift_id, cause)`.
5. `ops.register_evaluation(frame, label_source)`로 학습과 별개인 평가 패턴을 예약.
6. `ops.evaluate(candidate, evaluation_id)` 결과와 분포 안내 확인.
7. 통과한 평가만 `ops.promote(assessment_id)`. 필요시 `ops.rollback(kind, reason)`.
비라벨은 추론·감지만 가능하고 재학습에는 쓰지 않습니다.
RG3의 구간 안내에는 참조·평가 관측 수, 위험 이력, Wilson 구간과 표본 부족 표시가 들어갑니다.''')]
save_execute(ROOT/'03.modeling/04_operations.ipynb',cells)
