from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'modeling'))
from stacking_complementarity_experiment import topk, OUT, MODELS

# Tie handling: 2 seats among 4 identical scores, 2 positives.
r=topk(np.array([1,0,1,0]),np.ones(4),.5)
assert r['expected_TP']==1 and r['min_TP']==0 and r['max_TP']==2
assert topk(np.array([1,0,0,1]),np.array([4.,3.,2.,1.]),.5)['expected_TP']==1
checks=[]
for ds in ['cn7','rg3']:
    folder=OUT/ds
    manifest=json.loads((folder/'selection_manifest.json').read_text(encoding='utf-8'))
    val=pd.read_csv(folder/'validation_metrics.csv')
    winner=val.sort_values(['top10_expected_TP','AP','model'],ascending=[False,False,True]).iloc[0].model
    assert winner==manifest['selected']
    oof=pd.read_csv(folder/'oof_predictions.csv',float_precision='round_trip')
    test=pd.read_csv(folder/'test_predictions.csv',float_precision='round_trip')
    assert not(set(oof.row)&set(test.row))
    for label,frame,metricsfile in [('oof',oof,'validation_metrics.csv'),('test',test,'test_metrics.csv')]:
        metrics=pd.read_csv(folder/metricsfile).set_index('model')
        assert frame.row.is_unique
        for name in MODELS:
            y=frame.label.to_numpy(); s=frame[name].to_numpy()
            pred=s>manifest['thresholds'][name]
            tp=int(((y==1)&pred).sum()); fp=int(((y==0)&pred).sum())
            assert metrics.loc[name,'TP']==tp and metrics.loc[name,'FP']==fp
            for fraction in [.1,.2,.3]:
                k=int(np.ceil(len(y)*fraction)); cutoff=sorted(s,reverse=True)[k-1]
                above=y[s>cutoff]; tied=y[s==cutoff]
                expected=above.sum()+(k-len(above))*tied.mean()
                assert np.isclose(metrics.loc[name,f'top{int(fraction*100)}_expected_TP'],expected)
    roles=json.loads((folder/'nested_roles.json').read_text(encoding='utf-8'))
    for role in roles:
        tr,va,excluded=map(set,[role['train'],role['validation'],role['excluded']])
        assert not(tr&va or tr&excluded or va&excluded)
        assert not((tr|va)&set(test.row))
    checks.append(dict(dataset=ds,rows_disjoint=True,metrics_recomputed=True,selection_verified=True))
(OUT/'independent_verification.json').write_text(json.dumps(dict(status='passed',tie_tests=2,checks=checks),indent=2),encoding='utf-8')
print('Independent verification passed:',checks)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(12,4.5))
for ds,ax in zip(['cn7','rg3'],axes):
    v=pd.read_csv(OUT/ds/'validation_metrics.csv').set_index('model')
    t=pd.read_csv(OUT/ds/'test_metrics.csv').set_index('model')
    inds=np.arange(len(MODELS))
    ax.barh(inds-.18,v.loc[MODELS,'top10_expected_TP']/v.loc[MODELS,'positives'],height=.35,label='Nested development OOF')
    ax.barh(inds+.18,t.loc[MODELS,'top10_expected_TP']/t.loc[MODELS,'positives'],height=.35,label='Previously inspected test')
    ax.set_yticks(inds,['Random forest','Relationship residual','Isolation forest','Mean percentile','Stacking LR'])
    ax.set_xlim(0,1.05); ax.set_xlabel('Risk-pattern recall at top 10% inspection budget')
    ax.set_title(ds.upper()+f' | dev risks {int(v.iloc[0].positives)}, test risks {int(t.iloc[0].positives)}')
    ax.legend(fontsize=8,loc='lower right')
fig.tight_layout(); fig.savefig(OUT/'comparison.png',dpi=160); plt.close(fig)
