"""Create a self-contained code snapshot plus an executed, read-only result view."""
from pathlib import Path
import os
import nbformat as nbf
from nbclient import NotebookClient

root=Path(__file__).resolve().parents[1]
for variable, subdir in [('IPYTHONDIR','ipython'),('JUPYTER_RUNTIME_DIR','runtime'),('MPLCONFIGDIR','matplotlib')]:
    path=root/'tmp/relationship_notebook_runtime'/subdir
    path.mkdir(parents=True,exist_ok=True)
    os.environ[variable]=str(path)
source=(root/'modeling/relationship_residual_pipeline.py').read_text(encoding='utf-8')
source=source.split("if __name__=='__main__':")[0]
nb=nbf.v4.new_notebook()
nb.metadata.kernelspec={'display_name':'Python 3','language':'python','name':'python3'}
nb.cells=[
    nbf.v4.new_markdown_cell('''# CN7·RG3 정상 관계식과 잔차 학습

**질문:** 다른 공정값으로 예상한 값과 실제 값의 어긋남이 위험 판별에 도움이 되는가?

정상 관계식의 예측력과 불량 판별력을 별도로 확인합니다. 기존 자료를 관찰한 후속 실험이며, 현장 효과를 확정하지 않습니다.

이 노트북은 기본적으로 이미 실행한 결과를 읽습니다. 아래 코드에는 전체 파이프라인의 사본이 포함되어 있습니다. 새 실험을 실행하려면 설정 셀을 변경하세요. 기존 결과 폴더는 덮어쓰지 않습니다.'''),
    nbf.v4.new_markdown_cell('''## 1. 실행 가능한 전체 파이프라인

각 fold의 정상 참조 패턴과 분류기 학습 패턴을 분리합니다. 관계식은 자기 자신의 현재값을 입력으로 쓰지 않습니다. 참조 정상 OOF R²로 관계를 선별하고, 개발 validation에서 후보와 임계값을 정합니다.

`raw_full`은 전체 학습 자료 기준선, `raw_matched`는 잔차 모델과 동일한 지도학습 행 기준선입니다. 시간 실험은 원본 순서 가정 아래 과거 3행 정보를 사용하며, 패턴 실험과 정답의 의미가 다릅니다.'''),
    nbf.v4.new_code_cell(source),
    nbf.v4.new_code_cell("""RUN_NEW_EXPERIMENT = False
RUN_ID = '20261001_relations_v1'
if RUN_NEW_EXPERIMENT:
    result_dir = run_all(RUN_ID)
else:
    result_dir = ROOT/'output/relationship_residual'/RUN_ID
    assert (result_dir/'run_verification.json').exists(), '완료된 결과가 없습니다. 새 run id로 실행하세요.'
print(result_dir)
print((result_dir/'analysis_summary.txt').read_text(encoding='utf-8'))"""),
    nbf.v4.new_markdown_cell('''## 2. 실제 검증과 후속 test 결과

선택은 validation만으로 완료합니다. 아래 test 비교표의 최고 점수로 모델을 다시 고르지 않습니다. CN7 시간 실험은 미래 검증 불량이 없어 평가하지 않았습니다.'''),
    nbf.v4.new_code_cell("""from IPython.display import display, Image
for folder in sorted(result_dir.iterdir()):
    if folder.is_dir() and (folder/'test_comparison.csv').exists():
        print(folder.name)
        display(pd.read_csv(folder/'validation_comparison.csv'))
        display(pd.read_csv(folder/'test_comparison.csv'))
        display(Image(filename=str(folder/'comparison.png')))"""),
    nbf.v4.new_markdown_cell('''## 3. 변수 관계가 실제로 예측되는가?

R²는 정상 참조 자료 내부의 보지 않은 행에서 측정한 관계 예측력입니다. 이것이 높아도 정상·위험 분리력이 높다는 뜻은 아닙니다. test 정상에서의 관계 품질도 함께 봅니다.'''),
    nbf.v4.new_code_cell("""for folder in sorted(result_dir.iterdir()):
    if folder.is_dir() and (folder/'relationship_quality.png').exists():
        print(folder.name)
        display(Image(filename=str(folder/'relationship_quality.png')))
        display(pd.read_csv(folder/'test_normal_relationship_quality.csv'))"""),
    nbf.v4.new_markdown_cell('''## 4. 개별 사례의 관계 이탈과 선형 관계식

관계 이탈은 예측의 단서이며 불량 원인이나 물리 법칙이 아닙니다. 실제값/예상값은 제공 데이터 척도입니다.'''),
    nbf.v4.new_code_cell("""folder=result_dir/'rg3_fixed_pattern'
examples=pd.read_csv(folder/'test_residual_explanations.csv')
display(examples[examples.label.eq(1)].head(15))
equations=json.loads((folder/'linear_relationship_equations.json').read_text(encoding='utf-8'))
if equations:
    equation=equations[0]
    print(equation['target'], equation['equation'], 'intercept=',equation['intercept'])
    display(pd.DataFrame(equation['terms']))"""),
    nbf.v4.new_markdown_cell('''## 5. 재현과 한계

- 원본 CSV 해시와 기존 패턴 분할을 확인했습니다.
- fold별 참조/분류/검증 역할과 선택 manifest를 저장했습니다.
- 저장 모델 재로딩 후 점수 일치를 확인했습니다.
- 테스트 위험 사례 수가 적고 기존에 관찰한 자료입니다.
- 비라벨 파일에 대한 성능이나 운영 가능성을 주장하지 않습니다.
- 관계식이 정상 관계를 설명하는지와 그 잔차가 불량을 찾는지는 별개입니다.'''),
    nbf.v4.new_code_cell("""verification=json.loads((result_dir/'run_verification.json').read_text(encoding='utf-8'))
print('실행 완료:',verification['status'])
print('원본 보존:',verification['original_csv_unchanged'])
print('실험 실행 시간(초):',round(verification['elapsed_seconds'],2))"""),
]
path=root/'modeling/relationship_residual_analysis.ipynb'
nbf.write(nb,path)
NotebookClient(nb,timeout=120,kernel_name='python3',resources={'metadata':{'path':str(root)}}).execute()
nbf.write(nb,path)
print(path)
