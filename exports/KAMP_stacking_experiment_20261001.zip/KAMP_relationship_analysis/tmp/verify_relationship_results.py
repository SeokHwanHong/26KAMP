"""Independent arithmetic and role audit of persisted experimental outputs."""
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import joblib

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'modeling'))
from relationship_residual_pipeline import load_pattern,load_temporal

base=root/'output/relationship_residual/20261001_relations_v1'
checks=[]
for folder in base.iterdir():
    if not folder.is_dir() or not (folder/'test_comparison.csv').exists(): continue
    protocol=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
    temporal=protocol['protocol']=='temporal_assumed'
    ctx,x,y,g,dev,test,folds,_=(load_temporal(protocol['dataset']) if temporal else load_pattern(protocol['dataset']))
    plans=json.loads((folder/'role_plan.json').read_text(encoding='utf-8'))
    for plan in plans:
        ref,cl,va=(np.array(plan[k]) for k in ('reference_rows','classifier_rows','validation_rows'))
        assert not(set(ref)&set(cl) or set(ref)&set(va) or set(cl)&set(va))
        assert not(set(g[ref])&set(g[cl]) or set(g[ref])&set(g[va]) or set(g[cl])&set(g[va]))
        assert not(set(ref)&set(test) or set(cl)&set(test) or set(va)&set(test))
        assert (y[ref]==0).all()
    manifest=json.loads((folder/'selection_manifest.json').read_text(encoding='utf-8'))
    predictions=pd.read_csv(folder/'test_predictions.csv',float_precision='round_trip')
    table=pd.read_csv(folder/'test_comparison.csv',float_precision='round_trip').set_index('model')
    model=joblib.load(folder/'experiment.joblib')
    regenerated=model.predict(ctx.iloc[test].reset_index(drop=True),x.iloc[test].reset_index(drop=True))
    for name,part in predictions.groupby('model'):
        assert np.array_equal(part.row,test)
        assert np.array_equal(part.y,y[test])
        assert np.allclose(part.score,regenerated[name],rtol=0,atol=1e-12)
        t=manifest['thresholds'][name]
        prediction=(part.score.to_numpy()>t).astype(int)
        assert np.array_equal(prediction,part.prediction)
        tp=int(((part.y.to_numpy()==1)&(prediction==1)).sum())
        fp=int(((part.y.to_numpy()==0)&(prediction==1)).sum())
        fn=int(((part.y.to_numpy()==1)&(prediction==0)).sum())
        assert [tp,fp,fn]==[table.loc[name,k] for k in ('TP','FP','FN')]
        f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.
        assert np.isclose(f1,table.loc[name,'F1'])
    # Reproduce one saved linear equation directly from coefficients.
    equations=json.loads((folder/'linear_relationship_equations.json').read_text(encoding='utf-8'))
    if equations:
        eq=equations[0]
        manual=np.full(len(test),eq['intercept'])
        for term in eq['terms']:
            manual+=term['coefficient']*(ctx.iloc[test][term['predictor']].to_numpy()-term['center'])/term['scale']
        item=model.banks['ridge'].models[eq['target']]
        assert np.allclose(manual,item['model'].predict(ctx.iloc[test][item['predictors']]),atol=1e-10)
    checks.append(dict(experiment=folder.name,roles_disjoint=True,normal_reference_verified=True,
        test_predictions_reproduced=True,confusion_matrices_recomputed=True,equation_reproduced=True))
nb=json.loads((root/'modeling/relationship_residual_analysis.ipynb').read_text(encoding='utf-8'))
code=[c for c in nb['cells'] if c['cell_type']=='code']
assert all(c['execution_count'] is not None for c in code)
assert not any(o.get('output_type')=='error' for c in code for o in c.get('outputs',[]))
result=dict(status='passed',experiments=checks,notebook_executed_code_cells=len(code))
(base/'independent_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
for ds in ('cn7','rg3'):
    folder=base/f'{ds}_fixed_pattern'
    normal=pd.read_csv(folder/'test_normal_relationship_quality.csv')
    quality=pd.read_csv(folder/'ridge_final_relationships.csv')
    joined=quality.merge(normal[normal.backend.eq('ridge')],on='target')
    print(ds,'normal relations:')
    print(joined[['target','oof_r2','normal_r2']].sort_values('oof_r2',ascending=False).head(7).to_string(index=False))
